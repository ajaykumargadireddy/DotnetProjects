﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MYNTRA.Models
{
    class credentialsloic
    {
        string connectstring = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
        internal bool isNotVaild(string email)
        {
            string sql = $"select * from Customers where email= '{email}'";
            SqlConnection conn = new SqlConnection(connectstring);
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(sql, conn);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                    return false;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return true;
        }

        internal bool isValidSecurityAns(string email,string secans)
        {
            string sql = $"select * from Customers where email= '{email}' and securityans='{secans}'";
            SqlConnection conn = new SqlConnection(connectstring);
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(sql, conn);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    return true;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return false;
        }

        internal void updatepassword(string email, string text)
        {
            
            string sql = $"update customers set password='{text}' where email='{email}'";
            SqlConnection conn = new SqlConnection(connectstring);
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(sql, conn);
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public int isValidUser(string username, string password,out Customer c)
        {
            int res = 0;
            c = new Customer();
            string sql = $"select * from Customers where email= '{ username}'";
            SqlConnection conn = new SqlConnection(connectstring);
            try {
                conn.Open();
                SqlCommand command = new SqlCommand(sql, conn);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    res = 1;
                    if (reader.GetValue(1).ToString() == password)
                    {
                        res = 2;
                        
                        c.Email = reader.GetValue(0).ToString();
                        c.Password= reader.GetValue(1).ToString();
                        c.FullName= reader.GetValue(2).ToString();
                        c.Phone= reader.GetValue(3).ToString();
                        c.Address=reader.GetValue(4).ToString();
                        c.SecurityAns= reader.GetValue(5).ToString();
                    }
                }  
            }
            catch(Exception e)
            {
                res = -1;
            }
            finally
            {
                conn.Close();
            }
            return res;

        }

        internal void insertRow(Customer st)
        {
            string sql = "sproc_insert";
            SqlConnection conn = new SqlConnection(connectstring);
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(sql, conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@email", SqlDbType.VarChar, 50).Value=st.Email;
                command.Parameters.Add("@password", SqlDbType.VarChar, 50).Value = st.Password;
                command.Parameters.Add("@Fullname", SqlDbType.VarChar, 50).Value = st.FullName;
                command.Parameters.Add("@Phone", SqlDbType.VarChar, 50).Value = st.Phone;
                command.Parameters.Add("@Address", SqlDbType.VarChar, 50).Value = st.Address;
                command.Parameters.Add("@secqu", SqlDbType.VarChar, 50).Value = st.SecurityAns;
                command.ExecuteNonQuery();
                MessageBox.Show("Account Created Succesfully.Please Log in");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            
        }
    }

        
    
}
