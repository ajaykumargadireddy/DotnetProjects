﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYNTRA.Models;
namespace MYNTRA
{
    public partial class securityqsn : Form
    {
        string Email;
        credentialsloic cl = new credentialsloic();
        public securityqsn()
        {
            InitializeComponent();
        }
        public securityqsn(string email)
        {
            InitializeComponent();
            Email = email;
        }

        private void securityqsn_Load(object sender, EventArgs e)
        {
            emailtxt.Text = Email;
            panel1.Visible = false;
        }

        private void confirmbtn_Click(object sender, EventArgs e)
        {
            string email = emailtxt.Text;
            if (cl.isNotVaild(email))
                MessageBox.Show("Enter valid Mail address");
            else
            {
                string secans = secquetxt.Text;
                if (cl.isValidSecurityAns(email,secans))
                {
                    panel1.Visible = true;
                    emailtxt.Enabled = false;
                    secquetxt.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Incorrect Security answer");
                }
            }
            
        }

        private void createbtn_Click(object sender, EventArgs e)
        {
            if (newpwdtxt.Text != oldpwdtxt.Text)
                MessageBox.Show("Password Doesn't Match");
            else
            {
                string email = emailtxt.Text;
                cl.updatepassword(email, newpwdtxt.Text);
                MessageBox.Show("Password Updated Sucessfully");
                Login l = new Login();
                l.Show();
                this.Hide();
               
            }
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}
