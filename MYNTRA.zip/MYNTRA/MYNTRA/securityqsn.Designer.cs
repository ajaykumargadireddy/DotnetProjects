﻿namespace MYNTRA
{
    partial class securityqsn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.secquetxt = new System.Windows.Forms.TextBox();
            this.confirmbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.newpwdtxt = new System.Windows.Forms.TextBox();
            this.oldpwdtxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.createbtn = new System.Windows.Forms.Button();
            this.Loginbtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(38, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Email";
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(180, 52);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(184, 22);
            this.emailtxt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(38, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(386, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Security Question: What is your first school?";
            // 
            // secquetxt
            // 
            this.secquetxt.Location = new System.Drawing.Point(462, 112);
            this.secquetxt.Name = "secquetxt";
            this.secquetxt.Size = new System.Drawing.Size(184, 22);
            this.secquetxt.TabIndex = 3;
            // 
            // confirmbtn
            // 
            this.confirmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.confirmbtn.Location = new System.Drawing.Point(289, 155);
            this.confirmbtn.Name = "confirmbtn";
            this.confirmbtn.Size = new System.Drawing.Size(82, 31);
            this.confirmbtn.TabIndex = 4;
            this.confirmbtn.Text = "Confirm";
            this.confirmbtn.UseVisualStyleBackColor = false;
            this.confirmbtn.Click += new System.EventHandler(this.confirmbtn_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.createbtn);
            this.panel1.Controls.Add(this.oldpwdtxt);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.newpwdtxt);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(42, 213);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(689, 216);
            this.panel1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(24, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "New Password";
            // 
            // newpwdtxt
            // 
            this.newpwdtxt.Location = new System.Drawing.Point(198, 32);
            this.newpwdtxt.Name = "newpwdtxt";
            this.newpwdtxt.Size = new System.Drawing.Size(184, 22);
            this.newpwdtxt.TabIndex = 7;
            // 
            // oldpwdtxt
            // 
            this.oldpwdtxt.Location = new System.Drawing.Point(198, 97);
            this.oldpwdtxt.Name = "oldpwdtxt";
            this.oldpwdtxt.Size = new System.Drawing.Size(184, 22);
            this.oldpwdtxt.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label4.Location = new System.Drawing.Point(24, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "ConfirmPassword";
            // 
            // createbtn
            // 
            this.createbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.createbtn.Location = new System.Drawing.Point(247, 153);
            this.createbtn.Name = "createbtn";
            this.createbtn.Size = new System.Drawing.Size(82, 31);
            this.createbtn.TabIndex = 10;
            this.createbtn.Text = "Create";
            this.createbtn.UseVisualStyleBackColor = false;
            this.createbtn.Click += new System.EventHandler(this.createbtn_Click);
            // 
            // Loginbtn
            // 
            this.Loginbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Loginbtn.Location = new System.Drawing.Point(604, 26);
            this.Loginbtn.Name = "Loginbtn";
            this.Loginbtn.Size = new System.Drawing.Size(184, 31);
            this.Loginbtn.TabIndex = 6;
            this.Loginbtn.Text = "Login";
            this.Loginbtn.UseVisualStyleBackColor = false;
            this.Loginbtn.Click += new System.EventHandler(this.Loginbtn_Click);
            // 
            // securityqsn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Loginbtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.confirmbtn);
            this.Controls.Add(this.secquetxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.label1);
            this.Name = "securityqsn";
            this.Text = "securityqsn";
            this.Load += new System.EventHandler(this.securityqsn_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox secquetxt;
        private System.Windows.Forms.Button confirmbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button createbtn;
        private System.Windows.Forms.TextBox oldpwdtxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox newpwdtxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Loginbtn;
    }
}