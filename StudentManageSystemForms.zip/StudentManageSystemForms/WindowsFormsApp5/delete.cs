﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class delete : Form
    {
        public delete()
        {
            InitializeComponent();
        }

        private void dltsubmit_Click(object sender, EventArgs e)
        {
            if (Form1.students.ContainsKey((int.Parse(dltbutton.Text.ToString()))))
            {
                Form1.students.Remove(int.Parse(dltbutton.Text.ToString()));
                MessageBox.Show("Student is Removed from Directory");
            }
            else
            {
                MessageBox.Show("Student is Not in Directory");
            }
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
