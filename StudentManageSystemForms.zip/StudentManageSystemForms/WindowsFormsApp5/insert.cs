﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class insert : Form
    {
        Student s;
        public insert()
        {
            s = new Student();
            InitializeComponent();
        }

        private void SUBMITBUTTON_Click(object sender, EventArgs e)
        {
            s.Id = int.Parse(IDLBL.Text);
            s.Name = NAMELBL.Text;
            s.Course = COURSELBL.Text;
            s.Email = EMAILLBL.Text;
            s.fees = float.Parse(FESSLBL.Text);
            s.marks[0] = int.Parse(MARKS1LBL.Text);
            s.marks[1] = int.Parse(MARKS1LBL.Text);
            s.marks[2] = int.Parse(MARKS1LBL.Text);
            if (!Form1.students.ContainsKey(s.Id))
                Form1.students.Add(s.Id, s);
            else
                MessageBox.Show("Student is already in the list");
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

    }
}
