﻿namespace WindowsFormsApp5
{
    partial class insert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.IDLBL = new System.Windows.Forms.TextBox();
            this.NAMELBL = new System.Windows.Forms.TextBox();
            this.EMAILLBL = new System.Windows.Forms.TextBox();
            this.COURSELBL = new System.Windows.Forms.TextBox();
            this.MARKS1LBL = new System.Windows.Forms.TextBox();
            this.FESSLBL = new System.Windows.Forms.TextBox();
            this.MARKS2LBL = new System.Windows.Forms.TextBox();
            this.MARKS3LBL = new System.Windows.Forms.TextBox();
            this.SUBMITBUTTON = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Chocolate;
            this.label1.Location = new System.Drawing.Point(67, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Chocolate;
            this.label2.Location = new System.Drawing.Point(63, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(67, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 37);
            this.label3.TabIndex = 3;
            this.label3.Text = "EMAIL";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Chocolate;
            this.label4.Location = new System.Drawing.Point(66, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 39);
            this.label4.TabIndex = 2;
            this.label4.Text = "COURSE";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Chocolate;
            this.label5.Location = new System.Drawing.Point(67, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 28);
            this.label5.TabIndex = 5;
            this.label5.Text = "MARKS";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Chocolate;
            this.label6.Location = new System.Drawing.Point(67, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 40);
            this.label6.TabIndex = 4;
            this.label6.Text = "FEES";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // IDLBL
            // 
            this.IDLBL.Location = new System.Drawing.Point(209, 12);
            this.IDLBL.Multiline = true;
            this.IDLBL.Name = "IDLBL";
            this.IDLBL.Size = new System.Drawing.Size(124, 43);
            this.IDLBL.TabIndex = 6;
            // 
            // NAMELBL
            // 
            this.NAMELBL.Location = new System.Drawing.Point(209, 74);
            this.NAMELBL.Multiline = true;
            this.NAMELBL.Name = "NAMELBL";
            this.NAMELBL.Size = new System.Drawing.Size(124, 40);
            this.NAMELBL.TabIndex = 7;
            // 
            // EMAILLBL
            // 
            this.EMAILLBL.Location = new System.Drawing.Point(209, 207);
            this.EMAILLBL.Multiline = true;
            this.EMAILLBL.Name = "EMAILLBL";
            this.EMAILLBL.Size = new System.Drawing.Size(124, 37);
            this.EMAILLBL.TabIndex = 9;
            // 
            // COURSELBL
            // 
            this.COURSELBL.Location = new System.Drawing.Point(209, 148);
            this.COURSELBL.Multiline = true;
            this.COURSELBL.Name = "COURSELBL";
            this.COURSELBL.Size = new System.Drawing.Size(124, 39);
            this.COURSELBL.TabIndex = 8;
            // 
            // MARKS1LBL
            // 
            this.MARKS1LBL.Location = new System.Drawing.Point(209, 323);
            this.MARKS1LBL.Multiline = true;
            this.MARKS1LBL.Name = "MARKS1LBL";
            this.MARKS1LBL.Size = new System.Drawing.Size(124, 22);
            this.MARKS1LBL.TabIndex = 11;
            // 
            // FESSLBL
            // 
            this.FESSLBL.Location = new System.Drawing.Point(209, 259);
            this.FESSLBL.Multiline = true;
            this.FESSLBL.Name = "FESSLBL";
            this.FESSLBL.Size = new System.Drawing.Size(124, 40);
            this.FESSLBL.TabIndex = 10;
            // 
            // MARKS2LBL
            // 
            this.MARKS2LBL.Location = new System.Drawing.Point(407, 323);
            this.MARKS2LBL.Multiline = true;
            this.MARKS2LBL.Name = "MARKS2LBL";
            this.MARKS2LBL.Size = new System.Drawing.Size(118, 22);
            this.MARKS2LBL.TabIndex = 12;
            // 
            // MARKS3LBL
            // 
            this.MARKS3LBL.Location = new System.Drawing.Point(594, 320);
            this.MARKS3LBL.Multiline = true;
            this.MARKS3LBL.Name = "MARKS3LBL";
            this.MARKS3LBL.Size = new System.Drawing.Size(123, 22);
            this.MARKS3LBL.TabIndex = 13;
            // 
            // SUBMITBUTTON
            // 
            this.SUBMITBUTTON.BackColor = System.Drawing.Color.GreenYellow;
            this.SUBMITBUTTON.Location = new System.Drawing.Point(329, 377);
            this.SUBMITBUTTON.Name = "SUBMITBUTTON";
            this.SUBMITBUTTON.Size = new System.Drawing.Size(103, 44);
            this.SUBMITBUTTON.TabIndex = 14;
            this.SUBMITBUTTON.Text = "SUBMIT";
            this.SUBMITBUTTON.UseVisualStyleBackColor = false;
            this.SUBMITBUTTON.Click += new System.EventHandler(this.SUBMITBUTTON_Click);
            // 
            // insert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.SUBMITBUTTON);
            this.Controls.Add(this.MARKS3LBL);
            this.Controls.Add(this.MARKS2LBL);
            this.Controls.Add(this.MARKS1LBL);
            this.Controls.Add(this.FESSLBL);
            this.Controls.Add(this.EMAILLBL);
            this.Controls.Add(this.COURSELBL);
            this.Controls.Add(this.NAMELBL);
            this.Controls.Add(this.IDLBL);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "insert";
            this.Text = "insert";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox IDLBL;
        private System.Windows.Forms.TextBox NAMELBL;
        private System.Windows.Forms.TextBox EMAILLBL;
        private System.Windows.Forms.TextBox COURSELBL;
        private System.Windows.Forms.TextBox MARKS1LBL;
        private System.Windows.Forms.TextBox FESSLBL;
        private System.Windows.Forms.TextBox MARKS2LBL;
        private System.Windows.Forms.TextBox MARKS3LBL;
        private System.Windows.Forms.Button SUBMITBUTTON;
    }
}