﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class showdetails : Form
    {
        public showdetails()
        {
            InitializeComponent();
            

        }

        private void showdetails_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(Form1.students.Count().ToString());
            foreach (var key in Form1.students.Keys)
            {
                listView1.Items.Add(Form1.students[key].ToString());
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
