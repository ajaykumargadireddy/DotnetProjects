﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
  public class Student
    {
        public int Id;
        public string Name;
        public string Course;
        public string Email;
        public float fees;
        public int[] marks;
        public Student()
        {
            marks = new int[3];
        }
        public override string ToString()
        {
            string res="";
            res+="ID = "+Id.ToString()+" ";
            res +="Name = "+ Name + " " +"Course = "+ Course + " " + "Email = "+Email + " " + "Fees "+fees.ToString();
            res += " SUBJECT1 MARKS = " + marks[0].ToString();
            res+= " SUBJECT2 MARKS = " + marks[1].ToString();
            res+= " SUBJECT3 MARKS = " + marks[2].ToString();
            return res;

        }
    }
}
