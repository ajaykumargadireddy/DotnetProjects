﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void update_Load(object sender, EventArgs e)
        {
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            textBox6.Enabled = false;
            textBox7.Enabled = false;
            textBox8.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            if (Form1.students.ContainsKey(int.Parse(textBox1.Text)))
            {
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;

            }
            else
            {
                MessageBox.Show("Student Details Not in Portal");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student temp = Form1.students[int.Parse(textBox1.Text)];
            temp.Name = (textBox2.Text.Length == 0 || textBox2.Text == null) ? temp.Name : textBox2.Text;
            temp.Course = (textBox3.Text.Length == 0 || textBox3.Text == null) ? temp.Course : textBox3.Text;
            temp.Email = (textBox5.Text.Length == 0 || textBox5.Text == null) ? temp.Course : textBox5.Text;
            temp.fees = (textBox4.Text.Length == 0 || textBox4.Text == null) ? temp.fees : float.Parse(textBox4.Text);
            temp.marks[0]= (textBox6.Text.Length == 0 || textBox6.Text == null) ? temp.marks[0] : int.Parse(textBox6.Text);
            temp.marks[1] = (textBox7.Text.Length == 0 || textBox7.Text == null) ? temp.marks[1] : int.Parse(textBox7.Text);
            temp.marks[2] = (textBox8.Text.Length == 0 || textBox8.Text == null) ? temp.marks[2] : int.Parse(textBox8.Text);
        }
    }
}
