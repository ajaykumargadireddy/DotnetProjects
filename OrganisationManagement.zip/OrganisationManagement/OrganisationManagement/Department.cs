﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace OrganisationManagement
{
    class Department
    {
        public string deptid, numofprojects;
        public string deptname;
        public Department()
        {
            Console.Write("Enter department Id = ");
            deptid = Console.ReadLine();
            Console.Write("Enter department Name = ");
            deptname = Console.ReadLine();
            Console.Write("Enter numof projects in department = ");
            numofprojects= Console.ReadLine();
            Console.WriteLine($"Department with Id {deptid} is inserted");
        }

        public override string ToString()
        {
            return deptid.PadLeft(20)+deptname.ToString().PadLeft(20)+numofprojects.PadLeft(20)+"\n";
        }

        internal bool Presentinfile(string deptpath)
        {
            StreamReader reader = new StreamReader(deptpath);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(0,20));
                if (line.Substring(0, 20) == this.deptid.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
