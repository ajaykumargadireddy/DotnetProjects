﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace OrganisationManagement
{
    class Project
    {
        public string projectid, deptid, empid;
        public string projname;
        public Project()
        {
            Console.Write("Enter Project Id = ");
            projectid = Console.ReadLine();
            Console.Write("Enter ProjectName = ");
            projname = Console.ReadLine();
            Console.Write("Enter Dept Id = ");
            deptid = Console.ReadLine();
            Console.Write("Enter empid Id = ");
            empid = Console.ReadLine();
            Console.WriteLine($"Project with Id {projectid} is inserted");
        }

        public override string ToString()
        {
            return projectid.PadLeft(20)+projname.PadLeft(20)+deptid.PadLeft(20)+empid.PadLeft(20)+"\n";
        }

        internal bool Presentinfile(string projpath)
        {
            StreamReader reader = new StreamReader(projpath);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(0,20));
                if (line.Substring(0, 20) == this.projectid.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
