﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace OrganisationManagement
{
    class Employee
    {
        public string empid, deptid;
        public string empname, phone, email;
        public Employee()
        {
            Console.Write("Enter Employee id = ");
            empid = Console.ReadLine();
            Console.Write("Enter Employee name = ");
            empname = Console.ReadLine();
            Console.Write("Enter Employee E-mail = ");
            email = Console.ReadLine();
            Console.Write("Enter Employee phone = ");
            phone = Console.ReadLine();
            Console.Write("Enter Employee's dept id = ");
            deptid = Console.ReadLine();
            Console.WriteLine($"Employee with Id {empid} is inserted");
        }

        public override string ToString()
        {
            return empid.ToString().PadLeft(20)+empname.PadLeft(20)+email.PadLeft(20)+phone.PadLeft(20)+deptid.ToString().PadLeft(20)+"\n";
        }

        internal bool Presentinfile(string emppath)
        {
            StreamReader reader = new StreamReader(emppath);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(0,20));
                if (line.Substring(0, 20) == this.empid.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
