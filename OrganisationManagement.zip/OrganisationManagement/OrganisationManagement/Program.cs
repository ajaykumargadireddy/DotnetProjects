﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace OrganisationManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch,ch2;
            Console.WriteLine("1. Insert \n2. To get Employees by Departname \n3. GetProjects Managed by Manager \n4. Get Projects by DeptName \n5. Display EmployeeFile \n6. Display DepartmentFile \n7. Display ProjectFile \n8. exit");
            Console.Write("Enter the Option = ");
            ch = int.Parse(Console.ReadLine());
            string emppath = @"C:\Users\ajalw\Desktop\Employees.txt";
            string deptpath = @"C:\Users\ajalw\Desktop\Departments.txt";
            string projpath = @"C:\Users\ajalw\Desktop\Projects.txt",srch;
            while (ch != 8)
            {
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter 1. Insert Employee 2. Insert Department 3. Insert Project 4. Main Menu");
                        ch2 = int.Parse(Console.ReadLine());
                        while (ch2 != 4) {
                            switch (ch2)
                            {
                                case 1:
                                    Employee emp = new Employee();
                                    try {
                                        if (emp.Presentinfile(emppath)) {
                                            using (StreamWriter writer = new StreamWriter(emppath, true))
                                            {
                                                writer.Write(emp);
                                            }
                                        }
                                        else
                                            Console.WriteLine("Employee is already In the file");
                                    }
                                    catch(Exception ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }
                                    break;
                                case 2:
                                    Department dep=new Department();
                                    try
                                    {
                                        if (dep.Presentinfile(deptpath))
                                        {
                                            using (StreamWriter writer = new StreamWriter(deptpath, true))
                                            {
                                                writer.Write(dep);
                                            }
                                        }
                                        else
                                            Console.WriteLine("Department is already In the file");
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }
                                    break;
                                case 3:
                                    Project pro = new Project();
                                    try
                                    {
                                        if (pro.Presentinfile(projpath))
                                        {
                                            using (StreamWriter writer = new StreamWriter(projpath, true))
                                            {
                                                writer.Write(pro);
                                            }
                                        }
                                        else
                                            Console.WriteLine("Proect is already In the file");
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }
                                    break;
                            }
                            Console.WriteLine("Enter 1. Insert Employee 2. Insert Department 3. Insert Project 4. Main Menu");
                            ch2 = int.Parse(Console.ReadLine());
                        }
                        break;
                    case 2: Console.WriteLine("Enter department name To get all Employees of department");
                        srch = Console.ReadLine();
                        Helper.GetEmployeesBydeptName(srch,emppath,deptpath);
                        break;
                    case 3: Console.Write("Enter Manager ID: ");
                        srch = Console.ReadLine();
                        Helper.GetProjectByMGRId(srch, projpath, emppath);
                        break;
                    case 4:
                        Console.Write("Enter department name To get all Projects of the department :");
                        srch = Console.ReadLine();
                        Helper.GetProjectsBydeptName(srch, deptpath, projpath);
                        break;
                    case 5:Helper.display(emppath);
                        break;
                    case 6:Helper.display(deptpath);
                        break;
                    case 7:Helper.display(projpath);
                        break;
                    case 8:break;

                }
                Console.WriteLine("1. Insert \n2. To get Employees by Departname \n3. GetProjects Managed by Manager \n4. Get Projects by DeptName \n5. Display EmployeeFile \n6. Display DepartmentFile \n7. Display ProjectFile \n8. exit");
                Console.Write("Enter the Option = ");
                ch = int.Parse(Console.ReadLine());
            }
        }
    }
}
