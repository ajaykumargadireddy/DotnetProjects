﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace OrganisationManagement
{
    class Helper
    {
        public static void GetProjectsBydeptName(string srch, string deptpath, string projpath)
        {
            StreamReader reader = new StreamReader(deptpath);
            string deptid = null, line;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(20,20));
                if (line.Substring(20, 20) == srch.PadLeft(20))
                {
                    deptid = line.Substring(0, 20);
                    break;
                }
            }
            reader.Close();
            if (deptid == null)
                Console.WriteLine("Department id is not present in department file");
            else
            {
                reader = new StreamReader(projpath);
                int f = 0;
                while ((line = reader.ReadLine()) != null)
                {
                    //  Console.WriteLine(line.Substring(80, 20)+" "+deptid);
                    if (line.Substring(40, 20) == deptid)
                    {
                        if (f == 0)
                        {
                            Console.WriteLine("Projects in {0} department", srch);
                            Console.WriteLine("PROJECTID".PadLeft(20)+"PROJECTNAME".PadLeft(20)+"DEPTID".PadLeft(20)+"EMPID".PadLeft(20));
                        }
                        f = 1;
                        Console.WriteLine(line);
                    }
                }
                if (f == 0)
                    Console.WriteLine($"No Projects in {srch} department");
                reader.Close();
            }
        }
        public static void GetEmployeesBydeptName(string srch, string empath, string deptpath)
        {
            StreamReader reader = new StreamReader(deptpath);
            string deptid = null, line;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(20,20));
                if (line.Substring(20, 20) == srch.PadLeft(20))
                {
                    deptid = line.Substring(0, 20);
                    break;
                }
            }
            reader.Close();
            if (deptid == null)
                Console.WriteLine("Department id is not present in department file");
            else
            {
                reader = new StreamReader(empath);
                int f = 0;
                while ((line = reader.ReadLine()) != null)
                {
                    //  Console.WriteLine(line.Substring(80, 20)+" "+deptid);
                    if (line.Substring(80, 20) == deptid)
                    {
                        if (f == 0)
                        {
                            Console.WriteLine("Employees working in {0} department", srch);
                            Console.WriteLine("EMPID".PadLeft(20) + "EMPNAME".PadLeft(20) + "EMAIL".PadLeft(20) + "PHONE".PadLeft(20)+"DEPARTMENT".PadLeft(20));
                        }
                        f = 1;
                        Console.WriteLine(line);
                    }
                }
                if (f == 0)
                    Console.WriteLine($"No employees are working in {srch} department");
                reader.Close();
            }
        }

        internal static void GetProjectByMGRId(string srch, string projpath, string emppath)
        {
            StreamReader reader = new StreamReader(projpath);
            string line;
            int f = 0;
            while ((line = reader.ReadLine()) != null)
            {
                //Console.WriteLine(line.Substring(20,20));
                if (line.Substring(60, 20) == srch.PadLeft(20))
                {
                    if (f == 0)
                    {
                        Console.WriteLine("The projects under Manager with empid {0} are ", srch);
                        Console.WriteLine("PROJECTID".PadLeft(20) + "PROJECTNAME".PadLeft(20) + "DEPTID".PadLeft(20) + "EMPID".PadLeft(20));

                    }
                    Console.WriteLine(line);
                    f = 1;
                }
            }
            reader.Close();
            if(f==0)
                Console.WriteLine("Manager with id {0} is not present in project file");
            else
            {
                reader = new StreamReader(emppath);
                f = 0;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Substring(0, 20) == srch.PadLeft(20))
                    {
                        f = 1;
                        Console.WriteLine("The Manager Details are:");
                        Console.WriteLine("EMPID".PadLeft(20) + "EMPNAME".PadLeft(20) + "EMAIL".PadLeft(20) + "PHONE".PadLeft(20) + "DEPARTMENT".PadLeft(20));
                        Console.WriteLine(line);
                    }
                }
                if (f == 0)
                {
                    Console.WriteLine($"Manager id {srch} is not in the employee file");
                }
                reader.Close();
            }
        }

        public static void display(string path)
        {
            StreamReader reader = new StreamReader(path);
            int f = 0;
            string res,line;
            if(path.Contains("Employees"))
                res ="EMPID".PadLeft(20) + "EMPNAME".PadLeft(20) + "EMAIL".PadLeft(20) + "PHONE".PadLeft(20) + "DEPARTMENT".PadLeft(20);
            else if(path.Contains("Departments"))
                res = "DEPARTMENTID".PadLeft(20) + "DEPARTMENTNAME".PadLeft(20) + "NUMOFPRJCTS".PadLeft(20);
            else
                res = "PROJECTID".PadLeft(20) + "PROJECTNAME".PadLeft(20) + "DEPTID".PadLeft(20) + "EMPID".PadLeft(20);
            while ((line = reader.ReadLine()) != null)
            {
                if(f==0)
                    Console.WriteLine(res);
                f = 1;
                Console.WriteLine(line);
            }
            if(f==0)
                Console.WriteLine("No Contents in File");
            reader.Close();


        }
    }
}
