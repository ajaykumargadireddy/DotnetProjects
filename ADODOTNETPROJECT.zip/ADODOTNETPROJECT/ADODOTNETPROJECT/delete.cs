﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class delete : Form
    {
        public delete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentLogic sl = new StudentLogic();
            int id = Convert.ToInt32(numericUpDown1.Value);
            DataSet ds = sl.searchById(id);
            if (ds.Tables[0].Rows.Count >= 1)
            {
                sl.deletestudent(id);
            }
            else
            {
                MessageBox.Show("Student is not In the List");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            insert i = new insert();
            this.Hide();
            i.Show();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update u = new update();
            u.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delete d = new delete();
            d.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Visiting");
            Application.Exit();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
