﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADODOTNETPROJECT.MODELS;

namespace ADODOTNETPROJECT
{
    public partial class Details : Form
    {
        public Details()
        {
            InitializeComponent();
        }

        private void Details_Load(object sender, EventArgs e)
        {
            StudentLogic s = new StudentLogic();
            dataGridView1.DataSource = s.GetStudents();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            insert i = new insert();
            this.Hide();
            i.Show();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update u = new update();
            u.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delete d = new delete();
            d.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Visiting");
            Application.Exit();
        }
    }
}
