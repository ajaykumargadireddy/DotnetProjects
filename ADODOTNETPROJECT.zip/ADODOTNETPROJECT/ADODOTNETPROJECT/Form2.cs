﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            staffdetails sd = new staffdetails();
            sd.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form2insert F2I = new form2insert();
            F2I.Show();
            this.Hide();    
        }

        private void button4_Click(object sender, EventArgs e)
        {
            form2update form2Update = new form2update();
            form2Update.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            form2search form2Search = new form2search();
            form2Search.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            form2delete fd = new form2delete();
            fd.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            experienceemp emp = new experienceemp();
            emp.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            databaseform2 databaseform = new databaseform2();
            this.Hide();
            databaseform.Show();
            
        }
    }
}
