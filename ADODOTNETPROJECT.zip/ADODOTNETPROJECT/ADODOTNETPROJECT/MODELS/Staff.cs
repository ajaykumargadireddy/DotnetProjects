﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADODOTNETPROJECT.MODELS
{
    class Staff
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int experience { get; set; }
        public int CID { get; set; }
    }
}
