﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Configuration.Install;

namespace ADODOTNETPROJECT.MODELS
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public float Fees { get; set; }
        public float Percent { get; set; }
        public override string ToString()
        {
            return $"Id ={Id}, name={Name},Email={Email},phone={Phone},fees={Fees},percentage={Percent}";
        }
    }
}
