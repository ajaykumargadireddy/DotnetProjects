﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Configuration.Install;
using System.Windows.Forms;
using System.Data;

namespace ADODOTNETPROJECT.MODELS
{
    class StudentLogic
    {
        private string Connectstring = ConfigurationManager.ConnectionStrings["studb"].ConnectionString;

        public List<Student> GetStudents()
        {
            List<Student> li = new List<Student>();
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string query = "select * from Student";
                SqlCommand comm = new SqlCommand(query, conn);
                SqlDataReader dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    Student s = new Student();
                    s.Id = int.Parse(dr.GetValue(0).ToString());
                    s.Name = dr.GetValue(1).ToString();
                    s.Email= dr.GetValue(2).ToString();
                    s.Phone= dr.GetValue(3).ToString();
                    s.Fees = float.Parse(dr.GetValue(4).ToString());
                    s.Percent = float.Parse(dr.GetValue(5).ToString());
                    li.Add(s);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        internal List<Student> GetStudentsByPercentage(float percentage)
        {
            List<Student> li = new List<Student>();
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string query = "select * from Student where percentage >="+percentage;
                SqlCommand comm = new SqlCommand(query, conn);
                SqlDataReader dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    Student s = new Student();
                    s.Id = int.Parse(dr.GetValue(0).ToString());
                    s.Name = dr.GetValue(1).ToString();
                    s.Email = dr.GetValue(2).ToString();
                    s.Phone = dr.GetValue(3).ToString();
                    s.Fees = float.Parse(dr.GetValue(4).ToString());
                    s.Percent = float.Parse(dr.GetValue(5).ToString());
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        internal void deletestudent(int id)
        {
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand("spoc_delete", conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted Sucessfully");
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public DataSet searchById(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string sql = "select * from Student where Id=" + id.ToString();
                SqlDataAdapter adapter = new SqlDataAdapter(sql,conn);
                adapter.Fill(ds);
            }
            catch(Exception E)
            {
                MessageBox.Show(E.Message);
            }
            finally
            {
                conn.Close();
            }


            return ds;

            
        }

        internal string updatedetails(Student s)
        {
            string mes = "";
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string sql = "spoc_update";
                SqlCommand command = new SqlCommand(sql, conn);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@id",SqlDbType.Int).Value=s.Id;
                command.Parameters.Add("@name", SqlDbType.VarChar,50).Value = s.Name;
                command.Parameters.Add("@email", SqlDbType.VarChar,50).Value = s.Email;
                command.Parameters.Add("@phone", SqlDbType.VarChar, 50).Value = s.Phone;
                command.Parameters.Add("@fees", SqlDbType.Float).Value = s.Fees;
                command.Parameters.Add("@percentage", SqlDbType.Float).Value = s.Percent;
                command.ExecuteNonQuery();
                mes = "Succesfully Updated";
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return mes;
        }

        internal void insertStudent(string name, string email, string phone, float fees, float percentage)
        {
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string query = "insert into student(studentname,email,phone,fee,percentage) values ('"+name+ "','" + email + "','" + phone + "'," + fees + "," + percentage + ")";
                SqlCommand comm = new SqlCommand(query, conn);
                comm.ExecuteNonQuery();
                MessageBox.Show("Data inserted");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }

        }
        public DataSet gettabledata()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string sql = "select * from sys.tables;select * from student;select * from staff";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                adapter.Fill(ds);
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            finally
            {
                conn.Close();
            }


            return ds;


        }
    }
}
