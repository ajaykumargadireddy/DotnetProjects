﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data;

namespace ADODOTNETPROJECT.MODELS
{
    class StaffLogic
    {
        private string Connectstring = ConfigurationManager.ConnectionStrings["studb"].ConnectionString;

        internal List<Staff> GetStaffMem()
        {
            SqlConnection connection = new SqlConnection(Connectstring);
            List<Staff> li = new List<Staff>();
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("select * from staff", connection);
                SqlDataReader reader = command.ExecuteReader();
                
                while (reader.Read())
                {
                    Staff s = new Staff();
                    s.Id = int.Parse(reader.GetValue(0).ToString());
                    s.Name = reader.GetValue(1).ToString();
                    s.experience = int.Parse(reader.GetValue(2).ToString());
                    s.CID = int.Parse(reader.GetValue(3).ToString());
                    li.Add(s);
                }

            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }
            if (li.Count > 0)
                return li;
            else
            {
                MessageBox.Show("No Details for staff");
                return li;
            }
        }

        internal DataSet getTables()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(Connectstring);
            try
            {
                conn.Open();
                string sql = "select * from sys.tables;select * from student;select * from staff";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                adapter.Fill(ds);
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            finally
            {
                conn.Close();
            }


            return ds;
        }

        internal DataSet getemp(int emp)
        {
            SqlConnection connection = new SqlConnection(Connectstring);
            DataSet ds = new DataSet();
            try
            {

                connection.Open();
                string sql = "select * from staff where EXEPERIENCE>=" + emp;
                //MessageBox.Show(sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                adapter.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }
            return ds;

        }

        internal void deletestudent(int id)
        {
            SqlConnection connection = new SqlConnection(Connectstring);

            try
            {

                connection.Open();
                string sql = "delete from staff where id="+id;
                SqlCommand command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Erased");

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        internal void updatedetails(Staff s)
        {
            SqlConnection connection = new SqlConnection(Connectstring);
           
            try
            {

                connection.Open();
                string sql = "spoc_staffupdate";
                SqlCommand command = new SqlCommand(sql, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@id", SqlDbType.Int).Value = s.Id;
                command.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = s.Name;
                command.Parameters.Add("@experience", SqlDbType.VarChar, 50).Value = s.experience;
                command.Parameters.Add("@cid", SqlDbType.VarChar, 50).Value = s.CID;
                command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        internal DataSet SearchById(object id)
        {
            SqlConnection connection = new SqlConnection(Connectstring);
            DataSet ds = new DataSet();
            try
            {
                
                connection.Open();
                string sql =  "select * from staff where id="+id;
                //MessageBox.Show(sql);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                adapter.Fill(ds);
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }

            return ds;
        }

        internal void insertstaff(Staff staff)
        {
            SqlConnection connection = new SqlConnection(Connectstring);
            try
            {
                connection.Open();
                string sql = $"Insert into staff (staffname,EXEPERIENCE,cid) values ('" + staff.Name + "'," + staff.experience + "," + staff.CID + ")";
                SqlCommand command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
