﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(numericUpDown1.Value.ToString());
            StudentLogic sl = new StudentLogic();
            dataGridView1.DataSource=sl.searchById(id).Tables[0];
            dataGridView1.Visible = true;
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            insert i = new insert();
            this.Hide();
            i.Show();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update u = new update();
            u.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delete d = new delete();
            d.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Visiting");
            Application.Exit();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void mODIFYToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void rETRIEVEToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void bACKTOMAINToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
