﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class getstudents : Form
    {
        public getstudents()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float perecntage = float.Parse(textBox1.Text);
            StudentLogic sl = new StudentLogic();
            dataGridView1.DataSource = sl.GetStudentsByPercentage(perecntage);
            if (dataGridView1.Rows.Count >= 1)
            {
                dataGridView1.Visible = true;
                label4.Text = dataGridView1.Rows.Cast<DataGridViewRow>().Sum(t => float.Parse(t.Cells[5].Value.ToString())).ToString();
            }
            else
            {
                dataGridView1.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void getstudents_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
    }
}
