﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class update : Form
    {
        StudentLogic sl = new StudentLogic();
        public update()
        {
            InitializeComponent();
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void update_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            button2.Visible = false;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();

            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = int.Parse(numericUpDown1.Value.ToString());
            DataSet studentdeails = sl.searchById(id);
            if (studentdeails.Tables[0].Rows.Count > 0)
            {
                panel1.Visible = true;
                textBox1.Text=studentdeails.Tables[0].Rows[0]["studentname"].ToString();
                textBox2.Text= studentdeails.Tables[0].Rows[0]["email"].ToString();
                textBox3.Text = studentdeails.Tables[0].Rows[0]["Phone"].ToString();
                textBox4.Text = studentdeails.Tables[0].Rows[0]["Fee"].ToString();
                textBox5.Text = studentdeails.Tables[0].Rows[0]["Percentage"].ToString();
                button2.Visible = true;
            }
            else
            {
                MessageBox.Show($"No Student with {id} is present");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            Student s = new Student();
            int id = Convert.ToInt32(numericUpDown1.Value);
            s.Id = id;
            s.Name = textBox1.Text;
            s.Email = textBox2.Text;
            s.Phone = textBox3.Text;
            s.Fees =float.Parse(textBox4.Text);
            s.Percent = float.Parse(textBox4.Text);
            string message=sl.updatedetails(s);
           // MessageBox.Show(message);
            dataGridView1.Visible = true;
            dataGridView1.DataSource = sl.GetStudents();
            //dataGridView1.DataSource = sl.GetStudents();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
