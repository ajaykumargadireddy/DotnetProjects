﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class databaseform2 : Form
    {
        public databaseform2()
        {
            InitializeComponent();
        }

        private void databaseform2_Load(object sender, EventArgs e)
        {
            StaffLogic sl = new StaffLogic();
            cbtables.DataSource = sl.getTables().Tables[0];
            cbtables.DisplayMember = "name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ind = cbtables.SelectedIndex;
            StaffLogic sl= new StaffLogic();
            dataGridView1.DataSource = sl.getTables().Tables[++ind];
        }
    }
}
