﻿using ADODOTNETPROJECT.MODELS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADODOTNETPROJECT
{
    public partial class dbdetails : Form
    {
        StudentLogic sl = new StudentLogic();

        public dbdetails()
        {
            InitializeComponent();
        }

        private void dbdetails_Load(object sender, EventArgs e)
        {
            StudentLogic sl = new StudentLogic();
            cbtables.DataSource = sl.gettabledata().Tables[0];
            cbtables.DisplayMember = "name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ind = cbtables.SelectedIndex;
            dataGridView1.DataSource = sl.gettabledata().Tables[++ind];
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            insert i = new insert();
            this.Hide();
            i.Show();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update u = new update();
            u.Show();
            this.Hide();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delete d = new delete();
            d.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Visiting");
            Application.Exit();
        }
    }
}
