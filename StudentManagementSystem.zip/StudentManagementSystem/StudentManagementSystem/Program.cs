﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
   public class Program
    {
        static void Main(string[] args)
        {
            Admissions admin = new Admissions();
            Exams exm = new Exams();
            Reports rep = new Reports();
            Fees fee = new Fees();
           // List<Exams> Fees = new List<Exams>();
            Console.WriteLine("Enter option 1.Admission 2.Exams 3.Fees 4.ReportCard 5.Exit");
            int ch1, ch2,rid;
            ch1 = int.Parse(Console.ReadLine());
            while (ch1 != 5)
            {
                switch (ch1)
                {
                    case 1:Console.WriteLine("Enter option 1.BulkAdmissions 2.singleAdmission 3.RemoveAdmission 4.Display 5.MainMenu");
                        ch2 = int.Parse(Console.ReadLine());
                        while (ch2 != 5)
                        {
                            switch (ch2)
                            {
                                case 1:
                                        Console.Write("Enter  number of students ready for admission : ");
                                        int n = int.Parse(Console.ReadLine());
                                    for (int i = 0; i < n; i++)
                                        admin.GeTAdmissions();
                                    break;
                                case 2:
                                    admin.GeTAdmissions();
                                    break;
                                case 3:
                                    Console.Write("Enter student id To Remove: ");
                                    rid = int.Parse(Console.ReadLine());
                                    admin.RemoveById(rid);
                                    break;
                                case 4:
                                    admin.display();
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid choice");
                                    break;
                            }
                            Console.WriteLine("Enter option 1.BulkAdmissions 2.single Admission 3.Remove Admission 4.Display 5.MainMenu");
                            ch2 = int.Parse(Console.ReadLine());
                        }
                        break;
                   case 2:
                        Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.single Student 3.RemoveStudentBYId 4.Display 5.MainMenu");
                        ch2 = int.Parse(Console.ReadLine());
                        while (ch2 != 5)
                        {
                            switch (ch2)
                            {
                                case 1:
                                    exm.UpdateAll();
                                    break;
                                case 2:
                                    Console.Write("Enter student id To Enter: ");
                                    rid = int.Parse(Console.ReadLine());
                                    exm.Update(rid);
                                    break;
                                case 3:
                                    Console.Write("Enter student id To Remove: ");
                                    rid = int.Parse(Console.ReadLine());
                                    exm.RemoveById(rid);
                                    break;
                                case 4:
                                    exm.display();
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid choice");
                                    break;
                            }
                            Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.singleStudent 3.RemoveStudentBYId 4.Display 5.MainMenu");
                            ch2 = int.Parse(Console.ReadLine());
                        }
                        break;
                    case 4:
                        Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.singleStudent 3.RemoveStudentBYId 4.Display 5.MainMenu");
                        ch2 = int.Parse(Console.ReadLine());
                        while (ch2 != 5)
                        {
                            switch (ch2)
                            {
                                case 1:
                                    rep.UpdateAll();
                                    break;
                                case 2:
                                    Console.Write("Enter student id To Enter: ");
                                    rid = int.Parse(Console.ReadLine());
                                    rep.Update(rid);
                                    break;
                                case 3:
                                    Console.Write("Enter student id To Remove: ");
                                    rid = int.Parse(Console.ReadLine());
                                    rep.RemoveById(rid);
                                    break;
                                case 4:
                                    rep.display();
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid choice");
                                    break;
                            }
                            Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.single Student 3.RemoveStudentBYId 4.Display 5.MainMenu");
                            ch2 = int.Parse(Console.ReadLine());
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.singleStudent 3.RemoveStudentBYId 4.Display 5.MainMenu");
                        ch2 = int.Parse(Console.ReadLine());
                        while (ch2 != 5)
                        {
                            switch (ch2)
                            {
                                case 1:
                                    fee.UpdateAll();
                                    break;
                                case 2:
                                    Console.Write("Enter student id To Enter: ");
                                    rid = int.Parse(Console.ReadLine());
                                    fee.Update(rid);
                                    break;
                                case 3:
                                    Console.Write("Enter student id To Remove: ");
                                    rid = int.Parse(Console.ReadLine());
                                    fee.RemoveById(rid);
                                    break;
                                case 4:
                                    fee.display();
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid choice");
                                    break;
                            }
                            Console.WriteLine("Enter option 1.UpdateAllStudentsdetails 2.single Student 3.RemoveStudentBYId 4.Display 5.MainMenu");
                            ch2 = int.Parse(Console.ReadLine());
                        }


                        break;
                    default:Console.WriteLine("Please Enter Valid Choice");
                        break;

                }
                Console.WriteLine("Enter option 1.Admission 2.Exams 3.Fees 4.ReportCard 5.Exit");
                ch1 = int.Parse(Console.ReadLine());
            }
        }

    }
}
