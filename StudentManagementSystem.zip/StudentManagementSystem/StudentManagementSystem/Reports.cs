﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    class Reports
    {
        public static Dictionary<int, Reports> reportslist = new Dictionary<int, Reports>();
        public Dictionary<int, Admissions> al = Admissions.admissionslist;
        public int StudentId;
        float total;
        public string name,Grade;

        public Reports(int studentId, string name, float total, string grade)
        {
            StudentId = studentId;
            this.name = name;
            this.total = total;
            Grade = grade;
        }
        public Reports() { }

        public void GetReports(int studentId,string name,float total)
        {
            StudentId = studentId;
            this.name = name;
            this.total = total;
            if (this.total >= 80 && this.total <= 100)
                Grade = "A";
            else if (this.total >= 60)
                Grade = "B";
            else if (this.total >= 40)
                Grade = "C";
            else
                Grade = "FAIL";
            reportslist[StudentId] = new Reports(StudentId,name,total,Grade);
        }

        public void UpdateAll()
        {
            if (al.Count == 0)
                Console.WriteLine("No Conetnts available");
            else
            {

                foreach (var i in al) {
                    try
                    {
                        if (Exams.examlist.ContainsKey(i.Key))
                            GetReports(i.Key, i.Value.StudentName, Exams.examlist[i.Key].total);
                        else
                            throw new ManageException($"Error: Student with id {i.Key} hasn't enrolled for exams");
                    }
                catch (ManageException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        public void Update(int rid)
        {
            try
            {
                if (Exams.examlist.ContainsKey(rid))
                    GetReports(rid, al[rid].StudentName, Exams.examlist[rid].total);
                else
                    throw new ManageException("Student hasn't enrolled for exams");
            }
            catch (ManageException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public void RemoveById(int id)
        {
            try
            {
                if (reportslist.ContainsKey(id)) {
                    reportslist.Remove(id);
                    Console.WriteLine($"Contents with student id {id} is deleted in portal");
                }
                    
                else
                    throw new ManageException("Student Details Not in portal");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        internal void display()
        {
            if (reportslist.Count() == 0)
                Console.WriteLine("No Contents Available");
            else
            {
                foreach (var i in reportslist)
                    Console.WriteLine(i.Value);
            }
        }
        public override string ToString()
        {
            return $"studentid = {StudentId}  studentname = {name} Total = {total} Grade = {Grade}";
        }
    }
}
